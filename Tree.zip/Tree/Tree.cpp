#include <string>
#include "Tree.h"


Tree::Tree()
{
}

Tree::~Tree()
{
	Clear();
}

void Tree::Insert(int index)
{
	TreeNode* node = new TreeNode();
	node->index = index;

	if (root != nullptr)
	{
		TreeNode* target = root;
		bool insertFinish = false;	//���� �Ϸ�Ǹ� true. while �����
		
		while ( !insertFinish )	
		{
			if (target->index > index)
			{
				if (target->childLeft != nullptr)
				{
					target = target->childLeft;
				}
				else
				{					
					target->childLeft = node;
					insertFinish = true;
				}
			}
			else if (target->index < index)
			{
				if (target->childRight != nullptr)
				{
					target = target->childRight;
				}
				else
				{
					target->childRight = node;
					insertFinish = true;
				}
			}
			else
			{
				//���� ���ڰ� ������ �߰� ���� ����
				delete node;
				node = nullptr;
				insertFinish = true;
			}
		}
	}
	else
	{
		root = node;
	}
}

TreeNode* Tree::Find(int index)
{
	TreeNode* node = root;
	while (node != nullptr)
	{
		if (node->index < index)
		{
			node = node->childLeft;
		}
		else if (node->index > index)
		{
			node = node->childRight;
		}
		else
		{
			break;
		}
	}
	return node;
}

void Tree::Delete(int index)
{
	TreeNode* node = root;
	TreeNode* parentNode = nullptr;
	
	//������ ��� ã��
	while (node != nullptr)
	{
		if (node->index < index)
		{
			parentNode = node;
			node = node->childRight;
		}
		else if (node->index > index)
		{
			parentNode = node;
			node = node->childLeft;
		}
		else
		{
			//ã�Ҵ�.

			//��带 ������ �� ������ ����� �ڽ��� �ϳ��� �� ��ġ�� ����
			TreeNode** target = nullptr;	
			if ( node != root )
			{
				//������ ���� ��Ʈ�� �ƴϴ�.
				//�θ��� ���������� �������� Ȯ��				
				if ( parentNode->index > index )
				{
					target = &( parentNode->childLeft );
				}
				else
				{
					target = &( parentNode->childRight );
				}				
			}
			else
			{
				//�����Ұ��� ��Ʈ��
				target = &( root );
			}

			//������ ����� �ڽĵ� ó��
			if ( node->childLeft == nullptr && node->childRight == nullptr )
			{
				//�Ѵ� �����.
				( *target ) = nullptr;
			}
			else if ( node->childLeft != nullptr && node->childRight == nullptr )
			{
				//�ϳ��� �����.
				( *target ) = node->childLeft;
			}
			else if ( node->childLeft == nullptr && node->childRight != nullptr )
			{
				//�ϳ��� �����.
				( *target ) = node->childRight;
			}
			else
			{
				//�Ѵ� �ִ�.
				( *target ) = node->childLeft;
				TreeNode* childNode = node->childLeft;
				while ( childNode->childRight != nullptr )
				{
					childNode = childNode->childRight;
				}
				childNode->childRight = node->childRight;
			}

			//������ ����
			delete node;
			node = nullptr;
		}
	}
}

void Tree::Print()
{
	printf_s("Tree Print------------------------\n");
	Print(root);
	printf_s("\n----------------------------------\n\n");
}

void Tree::Print(TreeNode* node)
{
	if ( node )
	{
		Print(node->childLeft);
		printf_s("%d ", node->index);
		Print(node->childRight);
	}
}

void Tree::Clear()
{
	while ( root != nullptr )
	{
		Delete(root->index);
	}
}

void Tree::ReadData(char* inputFileName/* = nullptr*/)
{
	char filename[256] = "\0";
	if ( inputFileName != nullptr )
	{
		strcpy_s(filename, inputFileName);
	}
	else
	{
		strcpy_s(filename, "data_Tree.txt");
	}


	FILE* fp = nullptr;
	fopen_s(&fp, filename, "r");
	if ( fp != nullptr )
	{
		char line[256];
		while ( fgets(line, 256, fp) != nullptr )
		{
			//�Ľ�
			char* command = nullptr;
			char* parameter = nullptr;

			char* context = nullptr;
			char seperator[] = " :\n\0";
			command = strtok_s(line, seperator, &context);
			if ( command != nullptr )
			{
				parameter = strtok_s(nullptr, seperator, &context);

				//�Ľ��� ���ɾ�� ó��
				if ( strcmp("insert", command) == 0 )
				{
					Insert(atoi(parameter));
				}
				else if ( strcmp("delete", command) == 0 )
				{
					Delete(atoi(parameter));
				}
				else if ( strcmp("print", command) == 0 )
				{
					Print();
				}
				else
				{
					printf_s("Unknown command.\n");
				}
			}

		}
		fclose(fp);
	}
}