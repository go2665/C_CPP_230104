#pragma once
#include "TreeNode.h"

class Tree
{
public:
	Tree();
	~Tree();

	void Insert(int index);
	TreeNode* Find(int index);
	void Delete(int index);	
	
	void Print();	

	void ReadData(char* inputFileName = nullptr);

	void Clear();
private:
	TreeNode* root = nullptr;
	void Print(TreeNode* node);
};

